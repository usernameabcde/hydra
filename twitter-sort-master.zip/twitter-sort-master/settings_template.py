# settings.py
# Get yours at https://apps.twitter.com/

API_KEY = "Type_Your_API_KEY_HERE"
API_SECRET = "Type_Your_API_Secret_Here"
